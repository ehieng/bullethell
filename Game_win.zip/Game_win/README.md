# opengl-cpp-template
Opengl c++ template for vscode ide

This template is source code for this article https://medium.com/@vivekjha92/setup-opengl-with-vs-code-82852c653c43

Requirements for this template to work
1.  To run this template you should have GCC C++ compiler and the C/C++ extension for VS Code.
    To setup both, follow this https://code.visualstudio.com/docs/cpp/config-mingw#_prerequisites

How to run this project

1.  Clone this repo
2.  Open this repo as a folder in Visual Studio Code
3.  In VSCode menu under `Run` option select `run without debugging`